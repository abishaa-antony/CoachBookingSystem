/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author DELL
 */
public class DBConnectionClass {
    
    public static Connection createDBConnection() throws ClassNotFoundException{
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/coachdb","root","");
        return  con;
        }
        catch(ClassNotFoundException | SQLException ex){
        return null;
        }           
    
}
}
